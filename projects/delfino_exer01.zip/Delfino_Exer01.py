'''
CMSC 170 - Introduction to Artificial Intelligence

    Topic 1: User-Interface for the 8-puzzle game

    Exercise Description:
        Create an 8-puzzle game using either Java (with Java FX GUI Library) or Python (Any GUI Library).
        The goal of the game is to sort the board in ascending order (1,2,3,4,5,6,7,8,0). To generate the 
        board, it must read from a file ("puzzle.in").
        
@@author Bryan Kyle V. Delfino
@@date 2023-09-05  09:24

(c) Institute of Computer Science
'''

import random           # for generating the numbers in the board.
import tkinter as tk    # GUI Library used

rows = 3
columns = 3

# Function that generates a new puzzle.in file for the gameboard.
def writeFile():
    f = open("puzzle.in","w")

    matrix = []     # the 2d array to be constructed
    c = random.sample(range(9),9)   # c generates random UNIQUE numbers from 0 to 8.

    for i in range (0,len(c),3):
        new_c = []      # will be used to occupy randomly generated numbers. Each new_c array will have 3 numbers.
        new_c = c[i:i+3]    # adds the unique numbers to the array.
        matrix.append(new_c)    #Adds array to the matrix, making a new row of numbers.
    
    for i in range (rows):
        for j in range (columns):
            f.write(str(matrix[i][j]))      # writes the contents of the 2d array in a file and in matrix form.
        f.write("\n")

    f.close()

# Function that reads puzzle.in file.
def readFile():
   f = open("puzzle.in","r")
   
   matrix_to_array = []     # will be used to append all the matrix elements in the file.
   
   for numbers in f:
        for i in range (columns):
            matrix_to_array.append(int(numbers[i]))     # adds the numbers in the array.
    
   return matrix_to_array;      # returns the array, to be used for generating the gameboard.

   f.close()

# Checks if the board is solvable or not. Takes a 1d array as a parameter.
def isSolvable(gameboard):
    inversions = 0      # counter for inversions.
    empty_space = 0     # variable for the '0' element.

    for i in range(0, 9):
        for j in range(i + 1, 9):                                                                                   # for every element in the gameboard array, it will be compared to its succeeding elements. It will not compare to previously examined elements. 
            if gameboard[j] != empty_space and gameboard[i] != empty_space and gameboard[i] > gameboard[j]:         # if element that is being examined is being compared to is not a 0 and the current element being examined is greater than the element that is compared, then the inversion counter increments. 
                inversions += 1
    
    if inversions % 2 == 0:     # after the process of counting the inversions, if the number of inversions is an even number, then the board is solvable, returning a bool value of True.
        return True
    else:                       # otherwise, it returns a False.
        return False
    
# Function for acquiring the value of the button pressed.
def handleClick(btn_val):
    return btn_val

# The main game mechanics. It will take the value of the button and the button 2d array as parameters.
def gameMechanic(btn,gameboard):
    num_tile = handleClick(btn)     # will be acquiring the number of the button clicked.
    button_coor = ()                # An empty tuple for the position of the button pressed in the 2d array/matrix.
    zero_coor = ()                  # An empty tuple for the position of the empty button in the 2d array/matrix.
    button_coor_flag = False        # for breaking out of nested loops.
    zero_coor_flag = False
    
    for i in range(len(gameboard)):
        for j in range (len(gameboard[i])):
            if gameboard[i][j].cget('text') == str(num_tile):       # if the button that the user had pressed is found, the flag is set to true and the inner loop breaks.
                button_coor_flag = True
                break

        if button_coor_flag == True:                                # if the flag became true, button_coor tuple will be set to the position of the number in the matrix (x and y or i and j in this scenario).
            button_coor = (i,j)                                     # This also applies in finding position of the empty button in the matrix.
            break

    for i in range(len(gameboard)):
        for j in range (len(gameboard[i])):
            if gameboard[i][j].cget('text') == " ":
                zero_coor_flag = True
                break

        if zero_coor_flag == True:
            zero_coor = (i,j)
            break

    
    adj_coor = tuple(map(lambda i, j: i - j, button_coor, zero_coor))   # to get the adjacency of the button pressed and the empty tile, we subtract these tuples.
    

    if adj_coor == (-1,0):      # the swap will be performed if the button pressed is adjacent to the empty button at the downward directions.
        gameboard[button_coor[0]][button_coor[1]].config(text = " ", width = 22, height = 10, bg = "#13294B", 
                            activebackground = "#13294B", font = ("CenturyGothic", 9))
        (gameboard[button_coor[0]][button_coor[1]])["state"] = "disable"

        gameboard[zero_coor[0]][zero_coor[1]].config(text = str(btn), width = 22, height = 10, command = lambda t = btn: gameMechanic(t,gameboard), bg = "#189bcc", 
                                  activebackground = "#33C7F6", font = ("CenturyGothic", 9))  
        (gameboard[zero_coor[0]][zero_coor[1]])["state"] = "normal"

    elif adj_coor == (1,0):     # same procedure but the position is when the button pressed is adjacent to the empty button at the upward direction.
        gameboard[button_coor[0]][button_coor[1]].config(text = " ", width = 22, height = 10, bg = "#13294B", 
                            activebackground = "#13294B", font = ("CenturyGothic", 9))
        (gameboard[button_coor[0]][button_coor[1]])["state"] = "disable"

        gameboard[zero_coor[0]][zero_coor[1]].config(text = str(btn), width = 22, height = 10, command = lambda t = btn: gameMechanic(t,gameboard), bg = "#189bcc", 
                                  activebackground = "#33C7F6", font = ("CenturyGothic", 9))  
        (gameboard[zero_coor[0]][zero_coor[1]])["state"] = "normal"

    elif adj_coor == (0,-1):    # if the button pressed is adjacent to the empty button at the right direction.
        gameboard[button_coor[0]][button_coor[1]].config(text = " ", width = 22, height = 10, bg = "#13294B", 
                            activebackground = "#13294B", font = ("CenturyGothic", 9))
        (gameboard[button_coor[0]][button_coor[1]])["state"] = "disable"

        gameboard[zero_coor[0]][zero_coor[1]].config(text = str(btn), width = 22, height = 10, command = lambda t = btn: gameMechanic(t,gameboard), bg = "#189bcc", 
                                  activebackground = "#33C7F6", font = ("CenturyGothic", 9))  
        (gameboard[zero_coor[0]][zero_coor[1]])["state"] = "normal"

    elif adj_coor == (0, 1):    # if the button pressed is adjacent to the empty button at the left direction.
        gameboard[button_coor[0]][button_coor[1]].config(text = " ", width = 22, height = 10, bg = "#13294B", 
                            activebackground = "#13294B", font = ("CenturyGothic", 9))
        (gameboard[button_coor[0]][button_coor[1]])["state"] = "disable"

        gameboard[zero_coor[0]][zero_coor[1]].config(text = str(btn), width = 22, height = 10, command = lambda t = btn: gameMechanic(t,gameboard), bg = "#189bcc", 
                                  activebackground = "#33C7F6", font = ("CenturyGothic", 9))  
        (gameboard[zero_coor[0]][zero_coor[1]])["state"] = "normal"

    gameboard_checker = []                              # will be used to check the current state of the board.
    gameboard_win_condtion = [1,2,3,4,5,6,7,8,0]        # will be used as benchmark for the gameboard_checker.

    for row in range (len(gameboard)):                  # This nested loop populates the gameboard_checker list. Since we are getting the text from the buttons themselves courtesy of the 2d array of buttons, we have to convert these to integers. If it is an empty space, then we convert to a 0 integer.
        for col in range (len(gameboard[i])):
            if gameboard[row][col].cget("text") == " ":
                gameboard_checker.append(0)
            else:
                gameboard_checker.append(int(gameboard[row][col].cget("text")))

    if gameboard_checker == gameboard_win_condtion:     # if the gameboard_checker list is the same as the benchmark list, then the user wins.
        for i in range (len(gameboard)):                # this nested loop disables all the buttons in the gameboard, preventing changes to the successful gameboard.
            for j in range (len(gameboard[i])):
                (gameboard[i][j])["state"] = "disable"
        print("YOU WIN")                                # Prints the necesarry messages in the terminal.
        print("Exit the program and launch again for a new board!")

# Creates the main GUI for the game.
def createGUI():
    writeFile()                     # writes a new gameboard file called "puzzle.in".
    gameboard_array = readFile()    # reads "puzzle.in"       

    if isSolvable(gameboard_array):         # if the board is solvable, we generate the gameboard.
        root = tk.Tk()                      # will hold all the widgets to be made.

        root.geometry("492x483")            # set window size.
        root.resizable(False,False)         # window cannot be resized.
        root.title("8-Number Puzzle")

        gameboard_matrix = []               # will be used to hold the 2d array.

        for i in range (0,len(gameboard_array),3):      #'for' loop converts 1d array that is returned by the read file into a 2d array.
            gameboard_matrix_row = []
            gameboard_matrix_row = gameboard_array[i:i+3]
            gameboard_matrix.append(gameboard_matrix_row)

        for i in range (rows):                          # prints the 2d array in matrix format in the terminal.
            for j in range (columns):
                print(gameboard_matrix[i][j], end = " ")
            print()

        print("Solvable")               

        btn_frame = tk.Frame(root)                     # will be used for the grid of buttons.
        btn_frame.pack()                               # adds element to the root.

        gameboard_matrix_button = []                   # for the 2d array of buttons to be used by the gameMechanic function.
        

        for i in range (len(gameboard_matrix)):       # nested for loop to place all buttons in a grid and to append the buttons to the array.
            gameboard_matrix_button_row = []          # before adding to the gameboard_matrix_array, a 1d array of buttons will be made. After populating three buttons, this will be added to the gameboard_matrix_array.
            for j in range (len(gameboard_matrix[i])):
                num = gameboard_matrix[i][j]
                if num == 0:                            # if the current number is a 0, we set the button for it as follows:
                    b = tk.Button(btn_frame, text = " ", width = 22, height = 10, bg = "#13294B", 
                                  activebackground = "#13294B", font = ("CenturyGothic", 9))
                    b["state"] = "disable"
                else:                                   # otherwise, we set it like this:
                    b = tk.Button(btn_frame, text = str(num), width = 22, height = 10, command = lambda t = num: gameMechanic(t,gameboard_matrix_button), bg = "#189bcc", 
                                  activebackground = "#33C7F6", font = ("CenturyGothic", 9))         
                    b["state"] = "normal"

                b.grid(row = i + 1, column = j)         # current button will be placed at the specified row and column (with respect to the i and j loop counters.)
                gameboard_matrix_button_row.append(b)   # we append the button to the row of buttons list.

            gameboard_matrix_button.append(gameboard_matrix_button_row)     # we then add the row of buttons list as element to the gameboard_matrix_button list.This will be done until 3 row lists are added.
    else:                           # otherwise, we print a GUI message.
        root = tk.Tk()

        root.geometry("500x50")
        root.resizable(False,False)
        root.title("8-Number Puzzle")

        gameboard_matrix = []

        for i in range (0,len(gameboard_array),3):
            gameboard_matrix_row = []
            gameboard_matrix_row = gameboard_array[i:i+3]
            gameboard_matrix.append(gameboard_matrix_row)

        for i in range (rows):
            for j in range (columns):
                print(gameboard_matrix[i][j], end = " ")
            print()

        print("unsolvable")

        matrix = tk.Label (root, text = str(gameboard_matrix), anchor = "center", font = ("Century Gothic", 10))
        message = tk.Label(root, text = "New Board is Unsolvable! Close program and run again for new board.", anchor = "center", font = ("Century Gothic", 10))
        matrix.pack()
        message.pack()

    root.mainloop()        # we deploy everything.
    
createGUI()     # Launches program

    
