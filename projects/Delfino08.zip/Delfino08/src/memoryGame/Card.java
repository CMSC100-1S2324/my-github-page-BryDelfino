package memoryGame;
/***********************************************************
* This class defines the Card class. It has its own methods
* as well as different variations depending on their number
* and status (flipped or not flipped).
*
* @ author Bryan Kyle Delfino
* @ created_date ‎‎2023-04-30, ‏‎09:17
*
* *********************************************************/
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

public class Card {

	private int value
	;
	private Image cardBackImg;
	private Image numberImg;

	private Boolean revealed = false;
	private Boolean canBeFlipped = true;

	private ImageView imgView;
	private MainGameStage game;





	/**
	 *
	 * @param game		A reference to the MainGameStage
	 * @param value		the Card's "hidden value" to be matched with one other Card. A number from 1-8
	 * @param width		The length of the side of the card (the card is square)
	 */

	public Card(MainGameStage game, int value, int length) {

		this.game = game;
		this.value = value;

		// TODO: Initialize Image View
		//  - Load up the Card back image
		//  - Load up the image of the numbers
		//  - Setup layout properties and dimensions
		final Image CARD_BACK = new Image("images/card_back.jpg",length,length,false,false);
		this.cardBackImg = CARD_BACK; setCard(cardBackImg,length);
		final Image CARD_0 = new Image("images/0.jpg",length,length,false,false);
		final Image CARD_1 = new Image("images/1.jpg",length,length,false,false);
		final Image CARD_2 = new Image("images/2.jpg",length,length,false,false);
		final Image CARD_3 = new Image("images/3.jpg",length,length,false,false);
		final Image CARD_4 = new Image("images/4.jpg",length,length,false,false);
		final Image CARD_5 = new Image("images/5.jpg",length,length,false,false);
		final Image CARD_6 = new Image("images/6.jpg",length,length,false,false);
		final Image CARD_7 = new Image("images/7.jpg",length,length,false,false);
		final Image CARD_8 = new Image("images/8.jpg",length,length,false,false);
		final Image CARD_9 = new Image("images/9.jpg",length,length,false,false);

		switch(this.value){		// card face will change depending on the integer value that is being passed in the switch case.
			case 0: this.numberImg = CARD_0; setCard(numberImg,length); break;
			case 1: this.numberImg = CARD_1; setCard(numberImg,length); break;
			case 2: this.numberImg = CARD_2; setCard(numberImg,length); break;
			case 3: this.numberImg = CARD_3; setCard(numberImg,length); break;
			case 4: this.numberImg = CARD_4; setCard(numberImg,length); break;
			case 5: this.numberImg = CARD_5; setCard(numberImg,length); break;
			case 6: this.numberImg = CARD_6; setCard(numberImg,length); break;
			case 7: this.numberImg = CARD_7; setCard(numberImg,length); break;
			case 8: this.numberImg = CARD_8; setCard(numberImg,length); break;
			case 9: this.numberImg = CARD_9; setCard(numberImg,length); break;
		}
		setCardProperties(cardBackImg,length);		// sets and shows the back of the card.
		this.setHandler();							// when called, the current card is flipped and shows a number.
	}

	private void setHandler() {
		Card card = this;

		this.imgView.setOnMouseClicked(new EventHandler<MouseEvent>() {

			public void handle(MouseEvent e) {
				card.flip();						// when a downward-facing card is clicked, the card is flipped.
			}
		});
	}
	// setCard is a method that changes the appearance of the card. It is needed to show when a card is flipped or not flipped.
	private void setCard(Image img, int length){
		Canvas cardImg = new Canvas (length,length);
		GraphicsContext gcCard = cardImg.getGraphicsContext2D();
		gcCard.drawImage(img, 0, 0);
	}
	// setCardProperties define the specific sizes and properties of the card.
	private void setCardProperties(Image img, int length){
		this.imgView = new ImageView();
		this.imgView.setImage(img);
		this.imgView.setLayoutX(0);
		this.imgView.setLayoutY(0);
		this.imgView.setPreserveRatio(true);
		this.imgView.setFitWidth(length);
		this.imgView.setFitHeight(length);
	}
	// changes the face of the card.
	public void changeCardImage(Image card){
		this.imgView.setImage(card);
	}

	public void flip() {

		// check if the card can be flipped
		if (!canBeFlipped || !game.isFlippingAllowed()) { return; }
		// TODO: Hide or reveal the card
		if(this.revealed == false){					// if the card is not yet flipped or not yet revealed, then we can flip it and when clicked, it will show its corresponding number value.
			this.changeCardImage(numberImg);
			this.revealed = true;					// after it is flipped, we set this card to be revealed.
			// Check game state. Checking happens in MainGameStage.java
			game.checkState(this);					// using the game attribute, we check the state of the cards. More on this method on the MainGameStage class.
		}else{
			this.changeCardImage(this.cardBackImg);	// if revealed already, we change the image of the card back to its back side.
			this.revealed = false;					// then we set the 'revealed' attribute to false again.
		}
	}

	public ImageView getImageView() {
		return imgView;
	}

	public int getValue() {
		return value;
	}
	// a setter that sets the card's 'canBeFlipped' attribute. The boolean value of the card will depend on the parameter that is being passed.
	void setCanBeFlipped(Boolean tf){
		this.canBeFlipped = tf;
	}
}
