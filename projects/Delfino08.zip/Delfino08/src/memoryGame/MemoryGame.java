package memoryGame;
/***********************************************************
* This class is technically the main class. This class is
* responsible for launching the game.
*
* @ author Bryan Kyle Delfino
* @ created_date ‎‎2023-04-30, ‏‎09:17
*
* *********************************************************/
import javafx.application.Application;
import javafx.stage.Stage;

public class MemoryGame extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	public void start(Stage stage){
		@SuppressWarnings("unused")
		MainGameStage gameStage = new MainGameStage(stage);
	}

}
