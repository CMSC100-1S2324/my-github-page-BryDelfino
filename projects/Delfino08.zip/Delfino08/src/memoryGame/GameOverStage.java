package memoryGame;
/***********************************************************
* This class defines the game over screen which will show
* after the player gets all the card matches. This will show
* the number of moves a player has done to finish the game, as
* well as the ability to exit the program through an interactive
* UI (i. e. a button).
*
* @ author Bryan Kyle Delfino
* @ created_date ‎‎2023-04-30, ‏‎09:17
*
* *********************************************************/
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class GameOverStage {
	private Scene scene;

	GameOverStage(int moveCount, int windowWidth){

		Canvas canvas = new Canvas(windowWidth, windowWidth);										// a new canvas is declared. This will be used for the background.
		GraphicsContext gc = canvas.getGraphicsContext2D();											// the previously made canvas' graphics context was acquired using the Graphics Context type.
		Image bgImage = new Image("images/background.jpg",windowWidth,windowWidth,false,false);		// we then declare a new image object which will contain the background image that will be used for this scene.

		gc.drawImage(bgImage,0,0);																	// using the graphics context object, we draw the background image.

		// TODO: Add the move count message to the canvas
		gc.setFill(Color.BLACK);																	// for the game over texts, we once again use the graphics context object to modify the properties of the text such as the font color, font type, font size, and the text.
		Font theFont = Font.font("Times New Roman",FontWeight.BOLD,30);								// we define a new font object and specify the font size, font style, and font weight.
		gc.setFont(theFont);																		// we then set the font of the graphics context object using the recently instantiated font object.
		gc.fillText("You finished the board in " + moveCount + " moves!",20,220);					// we specify what text will be shown here as well as the moves it took the player to win the game. The x and y coordinates of the text in the window is also specified in here.


		Button exit = new Button("Exit Game");														// we instantiate a new button which will be the exit button. When clicked, this will terminate the program and close the window.
		exit.setOnMouseClicked(new EventHandler<MouseEvent>(){
			public void handle(MouseEvent arg0){
				System.exit(0);
			}
		});

		StackPane stackPane = new StackPane();														// a stack pane is instantiated. This will contain all the elements that we just defined earlier.

		stackPane.getChildren().addAll(canvas,exit);												// the stack pane will include the canvas (background image and text) and the exit button.

		this.scene = new Scene(stackPane, windowWidth, windowWidth);								// using the class' scene attribute, we instantiate a new scene which will contain the stack pane that we just made as well as the specific size of the window which is a constructor parameter.
	}


	Scene getScene(){
		return this.scene;
	}
}
