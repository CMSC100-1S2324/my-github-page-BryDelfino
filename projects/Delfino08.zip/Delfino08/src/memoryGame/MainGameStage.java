package memoryGame;
/***********************************************************
* This class defines the main mechanics of the
* Java memory game. It generates the grid of cards
* where the cards are acquired by instantiating an object
* of Card class, as well as sets the rules and mechanics
* of the game.
*
* @ author Bryan Kyle Delfino
* @ created_date ‎‎2023-04-30, ‏‎09:17
*
* *********************************************************/
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainGameStage {
	private Scene scene;
	private Stage stage;

	private Group root;
	private Canvas backgroundCanvas;
	private Canvas scoreCanvas;
	private GridPane cardGrid = new GridPane();
	private GraphicsContext gc;															// will be used for the background of the window.
	public final Image bg = new Image("images/background.jpg",500,500,false,false);		// creates an instance of an image that uses the background image.

	// The window is square so height is also 500
	public final static int WINDOW_WIDTH = 500;
	public final static int WINDOW_PADDING = 50;

	// the grid is square to the columns are also 4
	private final static int CARD_ROWS = 4;
	private final static int CARD_PADDING = 5;

	private Boolean startedPairOpening = false;											// boolean for starting the checking of cards.
	private Boolean flippingAllowed = true;												// boolean for the action of card flipping.

	private ArrayList<Card> cardCollection = new ArrayList<Card>();						// will contain all the cards that will be used whenever we execute the program.
	private Card[] openedCards = new Card[2];											// will contain the two cards that were clicked by the user.
	private int totalMatchedPairs = 0;													// a counter for the matched pairs a user has made.
	private int moveCount = 0;															// a counter for the moves a user made. Flipping 2 cards will result in 1 move.

	public MainGameStage(Stage stage) {

		this.stage = stage;

		this.root = new Group();														// we create a new group object called root which will contain all the leaf nodes that we have. These are background canvas, the score canvas, and the grid pane of cards.

		// TODO: Set background image Canvas
		this.backgroundCanvas = new Canvas(WINDOW_WIDTH,WINDOW_WIDTH);
		this.gc = backgroundCanvas.getGraphicsContext2D();
		this.gc.drawImage(this.bg, 0,0);
		this.root.getChildren().add(backgroundCanvas);									// for the background image to appear, we add the background canvas as a child of the root.



		// initializes the game elements (score display, cards)
		initGameElements();

		this.scene = new Scene(root, WINDOW_WIDTH, WINDOW_WIDTH, Color.WHITE);

		this.stage.setTitle("Memory Game");
		this.stage.setScene(this.scene);
		this.stage.show();

	}

	// Adds the score Canvas and card GridPane
	public void initGameElements() {

		// TODO: Create score canvas and add it to the root group
		scoreCanvas = new Canvas(WINDOW_WIDTH,WINDOW_WIDTH);							// we first create a new canvas object using the scoreCanvas attribute of this class.
		GraphicsContext gcScore = scoreCanvas.getGraphicsContext2D();					// we create a new graphics context object based on the canvas that we just made.

		Font scoreFont = Font.font("Times New Roman",30);								// we create a new font object defining the specific properties of the font.
		gcScore.setFont(scoreFont);														// we set the font of the graphics context object using the font object that we just made.
		gcScore.fillText("Moves: " + moveCount,0,50);									// we then set the specifics of the graphics context object like what it will say, the x and y coordinates.
		this.root.getChildren().add(scoreCanvas);										// finally, we add the canvas we just modified to the root.


		// Sets up the Card GridPane and add it to the root group
		initCards();
		root.getChildren().add(cardGrid);

	}

	private void initCards(){

		// Initalizes the 16 Cards, randomize their values, and it to the grid
		this.addCardsToGrid();

		// Sets the layout properties of the 4x4 card grid
		this.setGridLayoutProperties();
	}

	private void addCardsToGrid() {

		// calculates card length (square) based on window size, padding, number of cards in grid, and padding in between
		int cardLength = ((WINDOW_WIDTH - (WINDOW_PADDING * 2)) - ((CARD_ROWS - 1) * CARD_PADDING)) / CARD_ROWS;


		// TODO: Instantiate 16 cards with random values from 1-8, distributed among them twice. Add these cards to the gridPane property
		ArrayList<Integer>cardNumbers = new ArrayList<Integer>();		// an array list that will contain the numbers that will be shown in the proper game. We will use these numbers to create a card object of that corresponding number which will be added to the card collection. This array list is for the sole purpose of checking the numbers that will be used in the game.
		Random rand = new Random();										// in order to generate random card numbers, we will be using the Random object type.
		while(cardNumbers.size() < 16){									// a 'while' loop will be used to populate the cardNumbers array list. This will contain 8 pairs, or 16 cards where those cards will have their corresponding identical pairs.
			int number = rand.nextInt(8) + 1;							// generates the random number. (8) + 1 is done instead of just (9) due to a bug where it bricks the game. It bricks the game in a sense that there is a guaranteed chance that there are two non-identical cards or cards that are purely independent or does not have a pair.
			if (Collections.frequency(cardNumbers,number) == 2){		// checks if an integer has already 2 instances in the array. If case is met, then we continue the loop.
				continue;
			}else{														// but if that is not the case or if we met a case where there is only 1 or no instance of that integer in the array list,
				cardNumbers.add(number);								// we add that number to the array list.
				Card cardToAdd = new Card(this,number,cardLength);		// we use that number that we just acquire and make a new Card object which will have that number.
				cardCollection.add(cardToAdd);							// the card that we just created is then added to the cardCollection array list, ready for position in the grid box.
			}
		}
		int cardPicker = 0;												// this will be used in picking the cards in the cardCollection.
		for (int i = 0; i < MainGameStage.CARD_ROWS; i++){				// we will use a nested 'for' loop to place the cards in a specific row and column, based on the i and j counters.
			for (int j = 0; j < MainGameStage.CARD_ROWS; j++){
				GridPane.setConstraints(cardCollection.get(cardPicker).getImageView(), i, j);
				cardPicker++;											// after placing the card in the specific row and column, we increment the cardPicker counter so that we can index the next card in the array list.
			}
		}

		for(Card card : cardCollection){
			this.cardGrid.getChildren().add(card.getImageView());		// for the cards to show in the window when executed, we add these cards as children in the grid pane.
		}

	}

	// Layout properties such as padding around the grid, between the cards, etc.
	private void setGridLayoutProperties(){
		// TODO: Set layout properties. Use the WINDOW_WITH, WINDOW_PADDING, CARD_WIDTH, CARD_PADDING properties
		this.cardGrid.setPrefSize(MainGameStage.WINDOW_WIDTH,MainGameStage.WINDOW_WIDTH);		// The size of the outer box that will contain the grid of images.
		this.cardGrid.setLayoutX(MainGameStage.WINDOW_WIDTH*0.105);								// The x offset of the whole grid pane.
		this.cardGrid.setLayoutY(MainGameStage.WINDOW_WIDTH*0.125);								// The y offset of the whole grid pane.
		this.cardGrid.setVgap(MainGameStage.CARD_PADDING);										// The vertical gap of the individual images in the grid pane. This will give seperation to the cards.
		this.cardGrid.setHgap(MainGameStage.CARD_PADDING);										// The horizontal gap of the individual images in the grid pane.
	}


	private void updateScore() {
		// TODO: Clear the score canvas and display an updated one
		GraphicsContext gcScore = scoreCanvas.getGraphicsContext2D();
		gcScore.clearRect(0, 0, WINDOW_WIDTH,WINDOW_WIDTH);										// since we are updating the moves/scores, we must clear it first.
		Font scoreFont = Font.font("Times New Roman",30);
		gcScore.setFont(scoreFont);																// No increment will happen in this method since the incrementation of the moves will happen in the checkState method. We just simply update the face of the score canvas by modifying its graphic context similar to how we defined it in the initGameElements method.
		gcScore.fillText("Moves: " + moveCount, 0, 50);
	}


	void checkState(Card card) {

		// TODO: Disable flipping face down of the first card until a second card is revealed

		// this takes note of the first opened card
		if (startedPairOpening == false) {														// no cards are opened yet, we can flip a card.
			openedCards[0] = card;																// When a card is clicked, that card is added to the array of flipped cards.
			openedCards[0].setCanBeFlipped(false);												//we then set that card to be non-flippable using the setCanBeFlipped attribute of a card class.
		}

		// this takes note of the second opened card
		else {																					// if a card is opened and we want to flip another card,
			openedCards[1] = card;																// we put that flipped card in the array of flipped cards.
			// TODO: Update move count after every 2 cards opened
			this.moveCount++;																	// we update the move count by 1.
			this.updateScore();																	// and since we updated the move count, we want to call the updateScore method to show in the program the updated value of the moveCount counter.
			// TODO: Disable flipping cards globally while game state is checked
			this.flippingAllowed = false;														// since 2 cards are flipped (according to the array of flipped cards), we momentarily disable flipping to check these two cards.

			if(openedCards[0].getValue() == openedCards[1].getValue()){							// if the two cards in the flipped cards array are the identical, then we increment the matchedPairs counter by 1.
				this.totalMatchedPairs++;

				if(this.totalMatchedPairs == 8){												// we will also check if we have depleted all the cards in the grid pane or if we found all the matches.
					displayGameOverScene();														// if that is the case, we call the method responsible for showing the game over scene, signifying the end of the game.
				}else{																			// but if we have not reached yet to the point where the game ends,
					// TODO: If the cards match, no need to hide them again. Allow flipping cards again immediately
					openedCards[0].setCanBeFlipped(false);										// we set the two cards to be unflippable. They will only be facing up.
					openedCards[1].setCanBeFlipped(false);

					openedCards[0] = null;														// and to make room for the next pair of cards to be checked, we will set both elements in the flipped cards array to null.
					openedCards[1] = null;
					this.flippingAllowed = true;												// we can finally flip again cards after that.
				}
			}



			// TODO: If the cards don't match. Hide them after a 1 second delay. Do not allow flipping of other cards during the delay
			else {
				this.flippingAllowed = false;													// we disable flipping to check the two cards in the flipped cards array.

				PauseTransition delay = new PauseTransition(Duration.seconds(1));				// if they don't match, a 1 second pause/delay will occurr before the two unmatched cards are flipped down again.
				delay.play();
				// TODO: After the delay, flip down the 2 revealed cards. Enable flipping again after the delay
				delay.setOnFinished(new EventHandler<ActionEvent>(){							// after the 1 second delay,
					public void handle(ActionEvent arg0){
						setFlipping(true);														// we can flip again.
						openedCards[0].setCanBeFlipped(true);									// and we can flip the first card that we flipped again.

						openedCards[0].flip();													// we will flip the cards again back down using the flip method of the Card class.
						openedCards[1].flip();
					}
				});
			}



		}
		// This is for keeping track of the cards opened
		startedPairOpening = !startedPairOpening;
	}

	// a getter for the flippingAllowed attribute.
	Boolean isFlippingAllowed() {
		return flippingAllowed;
	}
	// will be used to set if a specific card can be flipped or not.
	private void setFlipping(boolean tf){
		this.flippingAllowed = tf;
	}

	private void displayGameOverScene(){
		PauseTransition transition = new PauseTransition(Duration.seconds(1));
		transition.play();

		transition.setOnFinished(new EventHandler<ActionEvent>() {

			public void handle(ActionEvent arg0) {
				GameOverStage gameover = new GameOverStage(moveCount, WINDOW_WIDTH);
				stage.setScene(gameover.getScene());
			}
		});
	}

}
