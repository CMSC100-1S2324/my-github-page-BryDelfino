'''
CMSC 12: Foundations of Computer Sciecne (Laboratory)

The Final Project is intended for Weeks 12-16

Problem Description:
   Create a Python Rock, Paper Scissors Game. Player that scores 5 points first is the winner. 
   Be creative in making the game. The following must also be present:
        1.) ASCII text.
        2.) Leaderboard feature. The lower the attempts, the better.

@@author Bryan Kyle Delfino
@@date 2021-12-20 21:20

(c) Institute of Computer Sciecne
'''
#note: PLEASE DO NOT DELETE ANY FILES INCLUDED IN THIS PYTHON ZIP FILE. IT WILL CAUSE SOME ERRORS IN THE GAME. THANKS!
import random   

name = ""   
score_player = 0
score_computer = 0
round_num = 0
win_lose_rec = {}
move_player = ""
move_computer = ""
Result = ""
Player_Data = {}
Leaderboard_Display_Fixed = []

#(31-60) A function that generates the main menu that the player will be interacting.
def main_menu():
    print("----------ROCK PAPER SCISSORS----------")
    print("                Game",round_num,"      ")
    print("|                                     |")
    print("| ----------------------------------- |")
    print("               "+name.upper()+"        ")
    print("| ----------------------------------- |")
    print("              SCORE:",score_player      )
    print("|             [1] Rock                |")
    print("|             [2] Paper               |")
    print("|             [3] Scissors            |")
    print("            Last Move:",move_player     )
    print("| ----------------------------------- |")
    print("|              COMPUTER               |")
    print("| ----------------------------------- |")
    print("             SCORE:",score_computer     )
    print("            Last Move:",move_computer   )
    print("|                                     |")
    print("| ----------------------------------- |")
    print("                  "+Result+"           ")
    print("| ----------------------------------- |")
    print("|            Other Options            |")
    print("|            [8] Top Players          |")
    print("|            [9] Restart              |")
    print("|            [0] Exit                 |")
    print("'-------------------------------------'")
    player_choice = int(input("Choice: ")) 
    
    return player_choice
#(61-66) A function that generates the computer's moves for the game.  
def computer_moves():
    computer_choice = ["Rock","Paper","Scissors"]   # A list containing all the possible moves in the game.
    computer_char = computer_choice[random.randint(0,2)]    # Elements of list are accessed randomly using the random.randint method from the Python Random Library.
    
    return computer_char
#(68-75) A function that generates a random name for the player.
def name_generator():
    Namebank = ["Albert","Allen","Bert","Bob","Cecil","Clarence","Elliot","Elmer","Ernie","Eugene","Fergus","Ferris","Frank","Frasier","Fred","George",
    "Graham","Harvey","Irwin","Larry","Lester","Marvin","Neil","Niles","Oliver","Opie","Ryan","Toby","Ulric","Ulysses","Uri","Waldo","Wally","Walt","Wesley",
    "Yanni","Yogi","Yuri","Alfred","Bill","Brandon","Calvin","Dean","Dustin","Ethan","Harold","Henry","Irving","Jason","Jenssen", "Josh","Martin","Nick","Norm",
    "Orin","Pat","Perry","Ron","Shawn","Tim","Will","Wyatt"]    # A list of names that the player can be assigned with.
    Rand_Name = Namebank[random.randint(0,len(Namebank))]   # Elements of list are randomly accessed through the random.randint method.
    
    return Rand_Name
#(77-113) A function that checks for the name of the user if it exists in the following files or not.
def name_checker(name):
    All_Players_Read = open("AllPlayersLatestScore.csv","r")    # Opens AllPlayersLatestScore.csv for reading. This file contains all the players and their latest attempt in the game. No duplicate names can be found.
    Leaderboard_File_Read = open("Leaderboard.csv","r")     # Opens Leaderboard.csv, the sorted version of AllPlayersLatestScore.csv.
    
    Top_5 =[0,1,2,3,4]      # List of integers for accessing the top 5 players.
    Leaderboard_Display_Local_Var = []      # Empty list for the names of the top 5 players.
    Leaderboard_Display_Local_Var_Fixed = []        # Empty list for the version of the top 5 players without the "\n" in the end of each names.
    Player_List = []    # Empty ;ist for all the players found in the AllPlayersLatestScore.csv. 
    for players, line in enumerate(Leaderboard_File_Read):  # For every player in the leaderboard.csv file,
        if players in Top_5:    # If the player is part of the Top 5,
            Leaderboard_Display_Local_Var.append(line)  # Then their data is added to the the Leaderboard_Display_Local_Var list.
            
    for elements in Leaderboard_Display_Local_Var:  # Removes the "\n" at the end of each element.  
        Leaderboard_Display_Local_Var_Fixed.append(elements.strip())
        
    Leaderboard_Display_to_str = " "    # Empty string for the list elements that will be converted to string.
    Leaderboard_Display_Local_string = Leaderboard_Display_to_str.join(Leaderboard_Display_Local_Var_Fixed)     # Elements of the Leaderboard_Display_Local_Var_Fixed are joined and converted into string.
    Leaderboard_Elements_List = Leaderboard_Display_Local_string.split()    # The string is then converted into a list and separates the names of the players from their scores.
    
    for player in All_Players_Read:     # For every player in the file AllPlayersLatestScore.csv,
        data = player[0:-1].split(",")  # The delimeter is removed,
        Player_List.append(data[0])     # And the names are stored in the Player_List list.
    for names in Player_List:       # For every name in the Player_List list,
        if name.upper() == names:   # If the name that is typed in by the player is in the Player_List list,
            print()
            print("Welcome back, "+ name +"!")  # Then the player with that name is welcomed back in the game.
            
    if name.upper() in Leaderboard_Elements_List:   # If the name typed in by the player is in the list of players that are part of the leaderboard,
        print("It's time to defend your spot in the Top 5 Leaderboard Rank!")   # Then they are also reminded that they will defend their spot in the leaderboard rank. More on this later.
        print()
    
    if name.upper() not in Player_List:     # If the name typed in by the player is not in the Player_List list, 
        print()
        print("Hello, "+ name +"! "+"Welcome to the game!") # Then they are introduced and are welcomed to the game.
        
    All_Players_Read.close()    
    Leaderboard_File_Read.close()
#(115-120) A function that writes a txt file containing the latest attempt of the latest player.
def CurrentPlayer_write(Player_Data):   
    Player_Data_List = [(k,v) for k,v in Player_Data.items()]   # Converts the dictionary item to a list containing a tuple.
    LastPlayer_file = open("LastPlayer.txt","w")    # Opens a txt file for writing the latest player with their latest attempt. It is stored in a txt file to ensure that all attempts are recorded and added to the AllPlayersAttempt.csv. More on this later.
    for x in Player_Data_List:  # For every player in the list containing tuples,
        LastPlayer_file.write(" ".join(str(s) for s in x)+"\n")     # The data from the tuple is extracted and is written to the txt file.
    LastPlayer_file.close()
#(122-144) A function that writes a csv file containing all the players who attempted the game with their latest attempt.        
def AllPlayers_write():
    Players = {}    # An empty dictionary for all the players and their value is the score of their latest attempt.
    AllPlayers_file = open("AllPlayersAttempts.csv","a")    # A file named AllPlayersAttempt.csv is opened for appending. This file must not be deleted. It contains all the players with all of their attempts. So duplicates can be seen.
    filehandle = open("LastPlayer.txt","r")     # The txt file containing the last player with their score for their latest attempt is read. 
    for player in filehandle:   # For every player in the txt file,
        data = player[0:-1].split(" ")  # The delimeter is removed,
        AllPlayers_file.write(data[0]+","+data[1]+"\n") # And the player with its data is added to the AllPlayersAttempts.csv. 
    AllPlayers_file.close()
    filehandle.close()
    
    AllPlayers_Read = open("AllPlayersAttempts.csv","r")    
    for players in AllPlayers_Read:     # For every players being read in the AllPlayersAttempts.csv,
        data = players[0:-1].split(",") # Their delimeter is removed,
        Player_Name = data[0]   # data[0] which contains the player's name is stored in a variable,
        Player_Score = data[1]  # data[1] which contains the player's score is stored in a variable.
        Players[Player_Name] = int(Player_Score)    # And the player's name is set as the key where its value is their score. Since All keys must be unique, it only takes the name of the player with their score in their latest attempt.
    AllPlayers_Read.close()
    
    All_Players_File_Fixed = open("AllPlayersLatestScore.csv","w")  # A new file will be written named AllPlayersLatestScore.csv which removes all the duplicates and only takes the player's latest score.
    Players_Data = Players.items()  # All items in the Players dictionary is converted into a list of tuple and is stored in a variable.
    for x in Players_Data:  # For ever item in the list of tuples,
        All_Players_File_Fixed.write(x[0] +","+ str(x[1])+"\n") # Each data is extracted from the tuple and the data is written to the file. 
    All_Players_File_Fixed.close()
#(146-187) A function that writes the leaderboard.csv, file, a sorted version of the AllPlayersLatestScore.csv file.             
def leaderboard_write(name):
    filehandle = open("AllPlayersLatestScore.csv","r")  
    Leaderboard = []    # An empty list that will contain all the players and their data in the csv file being read.
    for players in filehandle:  # For every player in the filehandle,
        data = players[0:-1].split(",") # Their delimeter is removed,
        Leaderboard_tup = (data[0],int(data[1]))    # And their data is turned into a tuple.
        Leaderboard.append(Leaderboard_tup) # The tuple is then added to the Leaderboard list.
    filehandle.close()
    Leaderboard_sorted = sorted(Leaderboard, key = lambda item:item[1])    # The Leaderboard list is then sorted from least to greatest based from their second element and it is stored in a variable.
    
    Leaderboard_file = open("Leaderboard.csv","w")  # A new file will be written which contains the items from the Leaderboard_sorted list.
    for items in Leaderboard_sorted:    # For every items in the list,
        Leaderboard_file.write(" ".join(str(s) for s in items)+"\n")    # The item is extracted from their respective tuple and their data is written in the file. 
    Leaderboard_file.close()
    #(161-174) Check lines 79-94 of the name checker function for the documentation. It's pretty much the same.
    Leaderboard_File_Read = open("Leaderboard.csv","r") 
    Top_5 =[0,1,2,3,4]
    Leaderboard_Display_Local_Var = []
    Leaderboard_Display_Local_Var_Fixed = []
    for players, line in enumerate(Leaderboard_File_Read):
        if players in Top_5:
            Leaderboard_Display_Local_Var.append(line)
            
    for elements in Leaderboard_Display_Local_Var:
        Leaderboard_Display_Local_Var_Fixed.append(elements.strip())
        
    Leaderboard_Display_to_str = " "
    Leaderboard_Display_Local_string = Leaderboard_Display_to_str.join(Leaderboard_Display_Local_Var_Fixed)
    Leaderboard_Elements_List = Leaderboard_Display_Local_string.split()
    if name.upper() in Leaderboard_Elements_List:   # If the player currently playing is part of the top 5 leaderboard or if they are still a part of the top 5 leaderboard, 
        print("""
   _____                            _         _       _   _                 _ 
  / ____|                          | |       | |     | | (_)               | |
 | |     ___  _ __   __ _ _ __ __ _| |_ _   _| | __ _| |_ _  ___  _ __  ___| |
 | |    / _ \| '_ \ / _` | '__/ _` | __| | | | |/ _` | __| |/ _ \| '_ \/ __| |
 | |___| (_) | | | | (_| | | | (_| | |_| |_| | | (_| | |_| | (_) | | | \__ \_|
  \_____\___/|_| |_|\__, |_|  \__,_|\__|\__,_|_|\__,_|\__|_|\___/|_| |_|___(_)
                     __/ |                                                    
                    |___/ 
        """)    
        print( name +", "+"You are one of the Top 5 Players.")  # Then the game congratulates them for being a part of the top 5 leaderboard.
    Leaderboard_File_Read.close()
#(189-323) A function that reads the leaderboard and displays the top 5.
def Leaderboard_read(Leaderboard_Display_Fixed):
    
    Leaderboard_Display_Fixed.clear()   # The Leaderboard-Display-Fixed list is cleared first to ensure no data complications occurr.
    filehandle = open("Leaderboard.csv","r")    # (192-202) Check lines 161 to 174 of the leaderboard_write function. It is similar. For documentation, check lines 79-94 of the AllPlayers_write function. 
    Top_5 = [0,1,2,3,4]     
    Leaderboard_Display = []
    for players, line in enumerate(filehandle):
        if players in Top_5:
            Leaderboard_Display.append(line)
    for elements in Leaderboard_Display:
        Leaderboard_Display_Fixed.append(elements.strip())
    Leaderboard_Display_to_str = " "
    Leaderboard_Display_string = Leaderboard_Display_to_str.join(Leaderboard_Display_Fixed)
    Leaderboard_Elements_List = Leaderboard_Display_string.split()
    filehandle.close()
    #(205-223) If the length of the list is equal to two or if there is one player in the top 5 leaderboard, then their data will be displayed with 4 more slots open for the leaderboard.
    if len(Leaderboard_Elements_List) == 2:
        print()
        print("----------ROCK PAPER SCISSORS----------")
        print("'                                     '")
        print("|                                     |")
        print("| ----------------------------------- |")
        print("|           Top 5 LEADERBOARD         |")
        print("| ----------------------------------- |")
        print("          1.) "+ Leaderboard_Elements_List[0] +" in "+Leaderboard_Elements_List[1]+" games.")
        print("          2.)                          ")
        print("          3.)                          ")
        print("          4.)                          ")
        print("          5.)                          ")
        print("| ----------------------------------- |")
        print("|                                     |")
        print("|                                     |")
        print("|                                     |")
        print("'-------------------------------------'")   
        print()
    #(225-243) If the length of the list is equal to 4 or if there are two player in the top 5 leaderboard, then their data will be displayed with 3 more slots open for the leaderboard.    
    elif len(Leaderboard_Elements_List) == 4:
        print()
        print("----------ROCK PAPER SCISSORS----------")
        print("'                                     '")
        print("|                                     |")
        print("| ----------------------------------- |")
        print("|           Top 5 LEADERBOARD         |")
        print("| ----------------------------------- |")
        print("          1.) "+ Leaderboard_Elements_List[0] +" in "+Leaderboard_Elements_List[1]+" games.")
        print("          2.) "+ Leaderboard_Elements_List[2] +" in "+Leaderboard_Elements_List[3]+" games.")
        print("          3.)                          ")
        print("          4.)                          ")
        print("          5.)                          ")
        print("| ----------------------------------- |")
        print("|                                     |")
        print("|                                     |")
        print("|                                     |")
        print("'-------------------------------------'")   
        print()
    #(245-263) If the length of the list is equal to six or if there are three player in the top 5 leaderboard, then their data will be displayed with 2 more slots open for the leaderboard.
    elif len(Leaderboard_Elements_List) == 6:
        print()
        print("----------ROCK PAPER SCISSORS----------")
        print("'                                     '")
        print("|                                     |")
        print("| ----------------------------------- |")
        print("|           Top 5 LEADERBOARD         |")
        print("| ----------------------------------- |")
        print("          1.) "+ Leaderboard_Elements_List[0] +" in "+Leaderboard_Elements_List[1]+" games.")
        print("          2.) "+ Leaderboard_Elements_List[2] +" in "+Leaderboard_Elements_List[3]+" games.")
        print("          3.) "+ Leaderboard_Elements_List[4] +" in "+Leaderboard_Elements_List[5]+" games.")
        print("          4.)                          ")
        print("          5.)                          ")
        print("| ----------------------------------- |")
        print("|                                     |")
        print("|                                     |")
        print("|                                     |")
        print("'-------------------------------------'")   
        print()
    #(265-283) If the length of the list is equal to eight or if there are four player in the top 5 leaderboard, then their data will be displayed with 1 more slot open for the leaderboard.
    elif len(Leaderboard_Elements_List) == 8:
        print()
        print("----------ROCK PAPER SCISSORS----------")
        print("'                                     '")
        print("|                                     |")
        print("| ----------------------------------- |")
        print("|           Top 5 LEADERBOARD         |")
        print("| ----------------------------------- |")
        print("          1.) "+ Leaderboard_Elements_List[0] +" in "+Leaderboard_Elements_List[1]+" games.")
        print("          2.) "+ Leaderboard_Elements_List[2] +" in "+Leaderboard_Elements_List[3]+" games.")
        print("          3.) "+ Leaderboard_Elements_List[4] +" in "+Leaderboard_Elements_List[5]+" games.")
        print("          4.) "+ Leaderboard_Elements_List[6] +" in "+Leaderboard_Elements_List[7]+" games.")
        print("          5.)                          ")
        print("| ----------------------------------- |")
        print("|                                     |")
        print("|                                     |")
        print("|                                     |")
        print("'-------------------------------------'")   
        print()
    #(285-303) If the length of the list is equal to or greater than ten or if there are five player in the top 5 leaderboard, then their data will be displayed.
    elif len(Leaderboard_Elements_List) >= 10:
        print()
        print("----------ROCK PAPER SCISSORS----------")
        print("'                                     '")
        print("|                                     |")
        print("| ----------------------------------- |")
        print("|           Top 5 LEADERBOARD         |")
        print("| ----------------------------------- |")
        print("          1.) "+ Leaderboard_Elements_List[0] +" in "+Leaderboard_Elements_List[1]+" games.")
        print("          2.) "+ Leaderboard_Elements_List[2] +" in "+Leaderboard_Elements_List[3]+" games.")
        print("          3.) "+ Leaderboard_Elements_List[4] +" in "+Leaderboard_Elements_List[5]+" games.")
        print("          4.) "+ Leaderboard_Elements_List[6] +" in "+Leaderboard_Elements_List[7]+" games.")
        print("          5.) "+ Leaderboard_Elements_List[8] +" in "+Leaderboard_Elements_List[9]+" games.")
        print("| ----------------------------------- |")
        print("|                                     |")
        print("|                                     |")
        print("|                                     |")
        print("'-------------------------------------'")   
        print()
    #(305-323) If the length of the list is equal to zero or if there is no player to fill up the leaderboard yet, then it will display 5 empty slots.   
    elif len(Leaderboard_Elements_List) == 0:
        print()
        print("----------ROCK PAPER SCISSORS----------")
        print("'                                     '")
        print("|                                     |")
        print("| ----------------------------------- |")
        print("|            Top 5 Players            |")
        print("| ----------------------------------- |")
        print("          1.)                          ")
        print("          2.)                          ")
        print("          3.)                          ")
        print("          4.)                          ")
        print("          5.)                          ")
        print("| ----------------------------------- |")
        print("|                                     |")
        print("|                                     |")
        print("|                                     |")
        print("'-------------------------------------'")   
        print()
              
print()
print(" ######    #######   #######  ########     ##     ##  #######  ########  ##    ## #### ##    ##  ######   ####")
print("##    ##  ##     ## ##     ## ##     ##    ###   ### ##     ## ##     ## ###   ##  ##  ###   ## ##    ##  ####") 
print("##        ##     ## ##     ## ##     ##    #### #### ##     ## ##     ## ####  ##  ##  ####  ## ##        ####") 
print("##   #### ##     ## ##     ## ##     ##    ## ### ## ##     ## ########  ## ## ##  ##  ## ## ## ##   ####  ## ") 
print("##    ##  ##     ## ##     ## ##     ##    ##     ## ##     ## ##   ##   ##  ####  ##  ##  #### ##    ##      ")
print("##    ##  ##     ## ##     ## ##     ##    ##     ## ##     ## ##    ##  ##   ###  ##  ##   ### ##    ##  ####") 
print(" ######    #######   #######  ########     ##     ##  #######  ##     ## ##    ## #### ##    ##  ######   ####")
print()
input_name = input("What is your name?: ")
if input_name == "":    # If the player did not enter a name,
    random_name = name_generator()  # Then a random name will be picked for the player using the name_generator function, 
    name = name+random_name # And it will be the name that will be used for this game session.
else:   # But if the player did type in a name,
    name=name+input_name    # Then the name that the player typed in will be used for this game session.
    
name_checker(name)  # The name that is being used in the game session will then be checked.
print("If not you, please press (0), start the game, and enter a new name.")    
print()   

class GetOutLoopNow(BaseException):     # (345-346) A line of code that will be used to terminate the program even in a nested loop.
    pass
#(348-735) Enclosed in a try to check the code for errors.        
try:                 
    #(350-735) Enclosed in a while loop for the game to continue until the player decides to terminate the game. Also used for catching invalid inputs.                                                                 
    while True:
        player_choice = main_menu() # main_menu function is called out and its return value is stored in a variable.
        computer_char = computer_moves()    # computer_moves function is called out and its return value is stored in a variable.
        if player_choice == 1:  # If the player chose 1 in the main menu, then their character is Rock.
            player_char = "Rock"
        elif player_choice == 2:    # But if the player chose 2 in the main menu, then their character is Paper.
            player_char = "Paper"
        elif player_choice == 3:    # But if the player chose 3 in the main menu, then their character is Scissors.
            player_char = "Scissors"
            
        elif player_choice == 8:    # But if the player chose 8 in the main menu, then the top 5 leaderboard will be displayed and the loop will continue so that the previous moves of the player and the computer will not change.
            Leaderboard_read(Leaderboard_Display_Fixed)
            continue    
        #(364-387) But if the player chose 9, then a prompt will appear if the user wants to restart the game or not.
        elif player_choice == 9:    
            Restart = input("Are you sure you want to restart game? All unsaved progress will be lost. (Y/N): ")
            if (Restart == "Y")or(Restart == "y"):  # If the user said yes to the prompt, then everything will reset.
                player_char = ""    # player_char will be empty.
                computer_char = ""  # computer_char will be empty 
                move_player = ""    # Last move by the player will be empty.
                move_computer =""   # Last move by the computer will be empty.
                Result = "" # The result will go back to being empty.
                score_player = score_player - score_player  # The player's score will go back to 0.
                score_computer = score_computer - score_computer    # The computer's score will go back to 0.
                round_num = round_num - round_num   # The round number will go back to zero.
                win_lose_rec.clear()    # The win_lose_rec dictionary will be cleared.
                print()
                print("Game Restarted Successfully!")
                print()
            elif (Restart == "N")or(Restart == "n"):    # But if the user said no, then the game will resume.
                print()
                continue
            else:   # If anything asides from the two options is typed, then the game will prompt the player to enter a valid option and the game will resume.
                print()
                print("Enter a valid option!")
                print("Returning to game...")
                print()
                continue
        #(389-398) But if the player chose option 0, then the game will end.  
        elif player_choice == 0:    
            print()
            print("..######..########.########....##....##..#######..##.....##....##....##.########.##.....##.########....########.####.##.....##.########.####")
            print(".##....##.##.......##...........##..##..##.....##.##.....##....###...##.##........##...##.....##..........##.....##..###...###.##.......####")
            print(".##.......##.......##............####...##.....##.##.....##....####..##.##.........##.##......##..........##.....##..####.####.##.......####")
            print("..######..######...######.........##....##.....##.##.....##....##.##.##.######......###.......##..........##.....##..##.###.##.######....##.")
            print(".......##.##.......##.............##....##.....##.##.....##....##..####.##.........##.##......##..........##.....##..##.....##.##...........")
            print(".##....##.##.......##.............##....##.....##.##.....##....##...###.##........##...##.....##..........##.....##..##.....##.##.......####")
            print("..######..########.########.......##.....#######...#######.....##....##.########.##.....##....##..........##....####.##.....##.########.####")
            break
        else:   # But if the player chose anything that is not in the main menu, then the game will prompt the player to choose a valid input and nothing will happen in the game. 
            player_char = "N/A"
            computer_char = "N/A"
            Result =""
            print("Enter a Valid Input!")
        
        #(406-428) If the player's character is Rock, and the computer's character is scissors, then the player wins.
        if player_char == "Rock":
            if computer_char == "Scissors":
                
                print("""
        _______                _______                       
    ---'   ____)          ____(____   '---   
         (_____)        (______
         (_____)       (__________
          (____)              (____)
    ---.__(___)                (___)__.---

____ ____ ____ _  _    ___  ____ ____ ___ ____    ____ ____ _ ____ ____ ____ ____ ____ 
|__/ |  | |    |_/     |__] |___ |__|  |  [__     [__  |    | [__  [__  |  | |__/ [__  
|  \ |__| |___ | \_    |__] |___ |  |  |  ___]    ___] |___ | ___] ___] |__| |  \ ___] 
                                                                                        
                """)
                
                score_player += 1   # The player's score counter will increment by 1. 
                move_player = player_char   # The last move by the player will be updated to the move that the player used.
                move_computer = computer_char   # The last move by the computer will be updated to the move that the player used.
                Result = "WIN"  # The result will be identified as a WIN.
                round_num += 1  # The round counter will increment by 1.
                win_lose_rec[round_num] = Result    # The game will be recorded by being added to the win_lose_rec dictionary where the round number is the key and the result of the round is the value.
            #(430-450) But if the computer's character is Rock, then it's a tie. The score counters will be incremented by 1.
            elif computer_char == "Rock":
                
                print("""
        _______              _______
    ---'   ____)            (____   '...
         (_____)          (_____)
         (_____)          (_____)
          (____)            (____
    ---.__(___)              (___)__.---       

_____ _______ . _______      _______      _______ _____ _______
  |      |    ' |______      |_____|         |      |   |______
__|__    |      ______|      |     |         |    __|__ |______
                                                                            
                """)

                move_player = player_char   # The last move by the player will be updated to the move that the player used.
                move_computer = computer_char   # The last move by the computer will be updated to the move that the player used.
                Result = "TIE"   # The result will be identified as a TIE.
                round_num += 1  # The round counter will increment by 1.
                win_lose_rec[round_num] = Result    # The game data will be added to the win_lose_rec dictionary.
            #(452-472) But if the computer's character is paper, then the player loses.
            else:
                print("""
        _______               _______     
    ---'   ____)         ____(____   '---
         (_____)       (______
         (_____)      (_______
          (____)        (_______
    ---.__(___)           (__________.---
            
____ ____ ____ _  _    _    ____ ____ ____ ____    ___ ____    ___  ____ ___  ____ ____ 
|__/ |  | |    |_/     |    |  | [__  |___ [__      |  |  |    |__] |__| |__] |___ |__/ 
|  \ |__| |___ | \_    |___ |__| ___] |___ ___]     |  |__|    |    |  | |    |___ |  \ 
                                                                                            
                """)
                
                score_computer += 1     # Computer's score counter will increment by 1.
                move_player = player_char   # The last move by the player will be updated to the move that the player used.
                move_computer = computer_char   # The last move by the computer will be updated to the move that the player used.
                Result = "LOSE" # The result will be identified as LOSE.
                round_num += 1  # The round counter will increment by 1.
                win_lose_rec[round_num] = Result    # The game data will be added to the win_lose_rec dictionary.
        #(474-496) But if the player chose the character Paper and the computer chose Rock, then the player wins.       
        elif player_char == "Paper":
            if computer_char == "Rock":
                
                print("""
        _______               _______
   ---'   ____)____         (____   '---
             ______)       (_____)
            _______)      (_____)
            _______)        (____)
   ---.__________)           (___)__.---

    ___  ____ ___  ____ ____    ___  ____ ____ ___ ____    ____ ____ ____ _  _ 
    |__] |__| |__] |___ |__/    |__] |___ |__|  |  [__     |__/ |  | |    |_/  
    |    |  | |    |___ |  \    |__] |___ |  |  |  ___]    |  \ |__| |___ | \_ 
                                                                            
                """)
                
                score_player += 1
                move_player = player_char
                move_computer = computer_char
                Result = "WIN"
                round_num += 1
                win_lose_rec[round_num] = Result
            #(498-518) But if the computer's character is also Paper, then it's a tie.    
            elif computer_char == "Paper":
                
                print("""
        _______               ______
   ---'   ____)____      ____(____  '---
             ______)   (______
            _______)   (_______
            _______)    (_______
   ---.__________)       (__________.---

_____ _______ . _______      _______      _______ _____ _______
  |      |    ' |______      |_____|         |      |   |______
__|__    |      ______|      |     |         |    __|__ |______
                                                                                                
                """)

                move_player = player_char
                move_computer = computer_char
                Result = "TIE"
                round_num += 1
                win_lose_rec[round_num] = Result
            #(520-539) But if the computer's character is Scissors, then the player lost.   
            else:
                print("""
        _______                _______                       
    ---'   ____)____      ____(____   '---   
              ______)    (______
              ______)   (__________
              ______)          (____)
    ---.__________)            (___)__.---            
                    
___  ____ ___  ____ ____    _    ____ ____ ____ ____    ___ ____    ____ ____ _ ____ ____ ____ ____ ____ 
|__] |__| |__] |___ |__/    |    |  | [__  |___ [__      |  |  |    [__  |    | [__  [__  |  | |__/ [__  
|    |  | |    |___ |  \    |___ |__| ___] |___ ___]     |  |__|    ___] |___ | ___] ___] |__| |  \ ___] 
                                                                                                            
                """)
                score_computer += 1
                move_player = player_char
                move_computer = computer_char
                Result = "LOSE"
                round_num += 1
                win_lose_rec[round_num] = Result
        #(541-562) But if the player's character is Scissors and the computer's character is Paper, then the player wins.       
        elif player_char == "Scissors":
            if computer_char == "Paper":
                print("""
        _______                 ______
    ---'   ____)____       ____(____  '---
              ______)     (______
          __________)    (_______
           (____)         (_______
    ---.__(___)            (__________.---

____ ____ _ ____ ____ ____ ____ ____    ___  ____ ____ ___    ___  ____ ___  ____ ____ 
[__  |    | [__  [__  |  | |__/ [__     |__] |___ |__|  |     |__] |__| |__] |___ |__/ 
___] |___ | ___] ___] |__| |  \ ___]    |__] |___ |  |  |     |    |  | |    |___ |  \ 
                                                                                        
                """)
                
                score_player += 1
                move_player = player_char
                move_computer = computer_char
                Result = "WIN"
                round_num += 1
                win_lose_rec[round_num] = Result
             #(564-584) But if the computer's character is also Scissors, then it's a tie.  
            elif computer_char == "Scissors":
                
                print("""
        _______                 ______
    ---'   ____)____       ____(____  '--- 
              ______)     (______
         __________)      (__________
         (____)               (____)
    ---.__(___)                (___)__.---    

  _____ _______ . _______      _______      _______ _____ _______
   |      |    ' |______      |_____|         |      |   |______
 __|__    |      ______|      |     |         |    __|__ |______
                                                                                
                """)

                move_player = player_char
                move_computer = computer_char
                Result = "TIE"
                round_num += 1
                win_lose_rec[round_num] = Result
            #(586-606) But if the computer's character is Rock, then the player lost.     
            else:
                print("""
        _______               _______
    ---'   ____)____         (____   '---
              ______)       (_____)  
         __________)        (_____)
           (____)            (____)
    ---.__(___)               (___)__.---

 ____ ____ _ ____ ____ ____ ____ ____    _    ____ ____ ____ ____    ___ ____    ____ ____ ____ _  _ 
[__  |    | [__  [__  |  | |__/ [__     |    |  | [__  |___ [__      |  |  |    |__/ |  | |    |_/  
___] |___ | ___] ___] |__| |  \ ___]    |___ |__| ___] |___ ___]     |  |__|    |  \ |__| |___ | \_ 
                                                                                                            
                """)
                
                score_computer += 1
                move_player = player_char
                move_computer = computer_char
                Result = "LOSE"
                round_num += 1
                win_lose_rec[round_num] = Result
        #(608-612) But if the player chose anything asides from the given characters, then it's an invalid input. The round number will not increment and the data will not be stored in the win_lose_rec dictionary.
        else:
            move_player = player_char
            move_computer = computer_char
            Result = ""
            round_num += 0
        #(614-675) If the player reached 5 points before the computer does, then the player is the winner of the game.    
        if score_player == 5:

            player_win_lose =[] # Empty list for the contents of win_lose_rec dictionary.
            print("""
    _           _                                    _             _     _                    _          
   (_)_       _(_)                                  (_)           (_)   (_)                  (_)         
     (_)_   _(_) _  _  _     _         _            (_)           (_) _  _     _  _  _  _    (_)         
       (_)_(_)_ (_)(_)(_) _ (_)       (_)           (_)     _     (_)(_)(_)   (_)(_)(_)(_)_  (_)         
         (_) (_)         (_)(_)       (_)           (_)   _(_)_   (_)   (_)   (_)        (_) (_)         
         (_) (_)         (_)(_)       (_)           (_)  (_) (_)  (_)   (_)   (_)        (_)             
         (_) (_) _  _  _ (_)(_)_  _  _(_)_          (_)_(_)   (_)_(_) _ (_) _ (_)        (_)  _          
         (_)    (_)(_)(_)     (_)(_)(_) (_)           (_)       (_)  (_)(_)(_)(_)        (_) (_)         
                                                                                                                                                                                                                                                                                                                                                                                                                         
                """)
            
            counter = 0 # Counter for accessing all the contents of the dictionary. This will be incremented through a for loop.
            win_lose_rec_keys = list(win_lose_rec.keys())   # A list of all the keys in the win_lose_rec dictionary is stored in a variable to access the round numbers.
            for values in win_lose_rec.values():     # for every value in the win_lose_rec_dictionary,
                print("Game" ,win_lose_rec_keys[counter] , values)  # These values are printed with their corresponding round number achieved. The round numbers are accessed through the list and the counter accessing its elements.
                player_win_lose.append(win_lose_rec_keys[counter])  # The empty list is appended with the elements of the win_lose_rec_keys list. 
                Player_Data[name.upper()] = len(player_win_lose)    # The Player_Data dictionary is then added a new key value pair where the key is the name of the player and the value is the length of the player_win_lose list which is the number of rounds taken before securing the win.
                counter += 1    # Counter is incremented by 1 to access all the elements of the win_lose_rec_keys dictionary.
                
            CurrentPlayer_write(Player_Data)    # The player_Data is then written in a txt file.
            AllPlayers_write()  # The player's data is then written to the file containing all the players' that played the game with their latest score. 
            leaderboard_write(name) # Their data is then written to the leaderboard file and analysed if they are part of the top 5 or not.
            
            print()
            print("Thank you for playing "+ name +"!")
            print()
            while True: #(645-675) Enclosed in a while loop to check for invalid inputs and to check if the player truly wants to play again or not.
                
                Play_Again = input("Play Again?(LEADERBOARD RANK MIGHT GET HIGHER OR LOWER BASED ON LATEST GAMEPLAY) (Y/N) (Press 8 for Leaderboards): ")
                print() 
                if (Play_Again == "Y")or(Play_Again == "y"):    # (648-658) If the player wants to play again, then everything will reset and this nested while loop will break, bringing the player back to the main game.
                    score_player = score_player - score_player
                    score_computer = score_computer - score_computer
                    round_num = round_num - round_num
                    win_lose_rec.clear()
                    Player_Data.clear()
                    player_win_lose.clear()
                    move_player = ""
                    move_computer = ""
                    Result = ""
                    break
                
                elif (Play_Again == "N")or(Play_Again == "n"):  #(661-668) But if the player does not want to play again, then the program will get terminate the whole game.
                    print("..######..########.########....##....##..#######..##.....##....##....##.########.##.....##.########....########.####.##.....##.########.####")
                    print(".##....##.##.......##...........##..##..##.....##.##.....##....###...##.##........##...##.....##..........##.....##..###...###.##.......####")
                    print(".##.......##.......##............####...##.....##.##.....##....####..##.##.........##.##......##..........##.....##..####.####.##.......####")
                    print("..######..######...######.........##....##.....##.##.....##....##.##.##.######......###.......##..........##.....##..##.###.##.######....##.")
                    print(".......##.##.......##.............##....##.....##.##.....##....##..####.##.........##.##......##..........##.....##..##.....##.##...........")
                    print(".##....##.##.......##.............##....##.....##.##.....##....##...###.##........##...##.....##..........##.....##..##.....##.##.......####")
                    print("..######..########.########.......##.....#######...#######.....##....##.########.##.....##....##..........##....####.##.....##.########.####")
                    raise GetOutLoopNow     # Helps in terminating the whole program despite being in a nested while loop.
                
                elif Play_Again == str(8):  #(670-671) But if the player wants to see the leaderboard, then the leaderboard will be displayed. Then the prompt will be asked again.
                    Leaderboard_read(Leaderboard_Display_Fixed)
                    continue
    
                else:   #(673-675) But if the user typed in anything that is not within the scope, then the game will prompt that the user typed in an invalid input and it will ask again for the user for an input.
                    print("Invalid option!")
                    print()
                    continue

        #(680-735) But if the computer reached 5 points before the player does, then the player is the loser of the game.      
        elif score_computer == 5:
            
            print("""
    _           _                                    _                                                            _          
   (_)_       _(_)                                  (_)                                                          (_)         
     (_)_   _(_) _  _  _     _         _            (_)               _  _  _       _  _  _  _     _  _  _  _    (_)         
       (_)_(_)_ (_)(_)(_) _ (_)       (_)           (_)            _ (_)(_)(_) _  _(_)(_)(_)(_)   (_)(_)(_)(_)_  (_)         
         (_) (_)         (_)(_)       (_)           (_)           (_)         (_)(_)_  _  _  _   (_) _  _  _ (_) (_)         
         (_) (_)         (_)(_)       (_)           (_)           (_)         (_)  (_)(_)(_)(_)_ (_)(_)(_)(_)(_)             
         (_) (_) _  _  _ (_)(_)_  _  _(_)_          (_) _  _  _  _(_) _  _  _ (_)   _  _  _  _(_)(_)_  _  _  _    _          
         (_)    (_)(_)(_)     (_)(_)(_) (_)         (_)(_)(_)(_)(_)  (_)(_)(_)     (_)(_)(_)(_)    (_)(_)(_)(_)  (_)         
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
            """)
            #(694-698) Displays all the contents of the win_lose_rec dictionary but its data will not be saved in the files.
            counter = 0
            win_lose_rec_keys = list(win_lose_rec.keys())
            for values in win_lose_rec.values():
                print("Game" ,win_lose_rec_keys[counter] , values)
                counter += 1
            print()
            print("Thank you for playing "+ name +"!")
            print()
            #(703-735) Check lines 645 to 675 for documentation.
            while True:
        
                Play_Again = input("Play Again? (Y/N) (Press 8 for Leaderboards): ")
                print()
                
                if (Play_Again == "Y")or(Play_Again == "y"):
                    score_player = score_player - score_player
                    score_computer = score_computer - score_computer
                    round_num = round_num - round_num
                    win_lose_rec.clear()
                    move_player = ""
                    move_computer = ""
                    Result = ""
                    break
                
                elif (Play_Again == "N")or(Play_Again == "n"):
                    print("..######..########.########....##....##..#######..##.....##....##....##.########.##.....##.########....########.####.##.....##.########.####")
                    print(".##....##.##.......##...........##..##..##.....##.##.....##....###...##.##........##...##.....##..........##.....##..###...###.##.......####")
                    print(".##.......##.......##............####...##.....##.##.....##....####..##.##.........##.##......##..........##.....##..####.####.##.......####")
                    print("..######..######...######.........##....##.....##.##.....##....##.##.##.######......###.......##..........##.....##..##.###.##.######....##.")
                    print(".......##.##.......##.............##....##.....##.##.....##....##..####.##.........##.##......##..........##.....##..##.....##.##...........")
                    print(".##....##.##.......##.............##....##.....##.##.....##....##...###.##........##...##.....##..........##.....##..##.....##.##.......####")
                    print("..######..########.########.......##.....#######...#######.....##....##.########.##.....##....##..........##....####.##.....##.########.####")
                    raise GetOutLoopNow
            
                elif Play_Again == str(8):
                    Leaderboard_read(Leaderboard_Display_Fixed)
                    continue
                      
                else:
                    print("Invalid option!")
                    print()
                    continue
#(737-738) Handles error by doing the action in the GetOutLoopNow class.
except GetOutLoopNow:
    pass